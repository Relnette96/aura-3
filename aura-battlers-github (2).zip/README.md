# Aura Battlers RPG

Jeu de battles d’aura façon RPG, en application web progressive (PWA) convertible en APK Android.

## Mise en ligne avec GitHub Actions

1. Crée un dépôt public sur GitHub (par exemple `aura-battlers-rpg`).
2. Envoie tout le contenu de ce dossier à la racine du dépôt, y compris le dossier caché `.github`.
3. Dans **Settings > Pages**, choisis **GitHub Actions** comme source.
4. Le déploiement se lance à chaque envoi sur `main`. Suis-le dans l’onglet **Actions** : l’adresse s’affiche à la fin, sous la forme `https://ton-pseudo.github.io/aura-battlers-rpg/`.

## Création de l’APK

1. Va sur pwabuilder.com et colle l’adresse GitHub Pages.
2. Choisis Android, puis génère le paquet.
3. Garde précieusement la clé de signature fournie dans le ZIP : elle est indispensable pour publier des mises à jour.

## Contenu

- `index.html` : l’application complète
- `manifest.json` : nom, couleurs et icônes de l’app installée
- `sw.js` : service worker pour l’usage hors connexion
- `icon-*.png` : icônes (dont une version « maskable » pour Android)
- `.github/workflows/deploy.yml` : déploiement automatique sur GitHub Pages
